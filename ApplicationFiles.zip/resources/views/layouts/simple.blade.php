@include('./partials.head')

<body>
    <div class="wrapper">
        <div class="content">
            <div id="app" class="pt-2 m-0">
                @yield('content')
            </div>
        </div>
    </div>
</body>
</body>

</html>
