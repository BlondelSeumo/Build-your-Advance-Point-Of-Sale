<div class="text-center mb-0 pb-0">
    <small>&copy; Copyright {{ date('Y') }} <a href="https://codecanyon.net/user/rose-finch">Rose Finch</a> All
        Rights
        Reserved</small>
    | <a href="mailto:info.codehas@gmail.com" data-toggle="tooltip" title="info.codehas@gmail.com">Contact Us</a>
    - <a href="https://codecanyon.net/item/advance-point-of-sale/25741262/support" data-toggle="tooltip"
        title="Rose Finch's portfolio at codecanyon">Help Portfolio</a>
</div>
