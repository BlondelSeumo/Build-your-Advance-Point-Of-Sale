 @push('script')
     <script>
         "use strict";
         var pageURL = '{{ $pageLink }}';
     </script>
 @endpush
