"use strict";
$(document).ready(function() {
    window.print();
});
